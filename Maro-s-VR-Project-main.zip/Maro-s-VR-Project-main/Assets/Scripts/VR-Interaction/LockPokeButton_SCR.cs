using System;
using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit.Filtering;

public class LockPokeButton_SCR : PokeButton_SCR
{
    // header
    [Header("Lock Button Specifics")]
    public Transform middlePoint;
    private bool LockButtonIsPressed = false;

    public override void OnPokeStateDataUpdated(PokeStateData data)
    {
        var pokeTarget = data.target;
        var applyFollow = true
            ? pokeTarget != null && pokeTarget.IsChildOf(transform)
            : pokeTarget == transform;

        if (applyFollow)
        {
            var beginPointButtonY = !LockButtonIsPressed ? buttonOriginalLocalPosition.y : button.transform.parent.transform.InverseTransformPoint(middlePoint.transform.position).y;
            // get the parent of the button
            var buttonsParent = button.transform.parent.transform;

            // get the poke interaction point
            var pokeInteractionPoint = data.pokeInteractionPoint;
            // get the closest point on the up axis of the button to the poke interaction point
            var closestPoint = buttonsParent.InverseTransformPoint(pokeInteractionPoint);

            // get the y position of the button in the parent's local space
            float endpointButtony = buttonsParent.InverseTransformPoint(endPoint.transform.position).y;

            // get the min and max y positions of the button in the parent's local space
            float min = Math.Min(endpointButtony, beginPointButtonY);
            float max = Math.Max(endpointButtony, beginPointButtonY);

            // clamp the y position of the closest point to the min and max y positions
            float clampedY = Mathf.Clamp(closestPoint.y, min, max);
            // set the new local position of the button
            newLocalPosition(new Vector3(button.transform.localPosition.x, clampedY, button.transform.localPosition.z));
            checkButtonPressed(clampedY);
        }
        else
        {
            resetButton();
        }

    }

    public override void checkButtonPressed(float clampedY)
    {
        // Get the y position of the endpoint in the button's local space
        float endpointButtony = button.transform.parent.transform.InverseTransformPoint(endPoint.transform.position).y;

        // Check if the button's position is within the threshold of the endpoint's position
        if (Mathf.Abs(clampedY - endpointButtony) <= pressThreshold && !buttonIsPressed)
        {
            if (LockButtonIsPressed)
            {
                onButtonReleased.Invoke();
            }
            else
            {
                onButtonPressed.Invoke();
            }
            //avoid consequent button press triggers
            buttonIsPressed = true;
            LockButtonIsPressed = !LockButtonIsPressed;
        }
        else if (Mathf.Abs(clampedY - endpointButtony) > pressThreshold && buttonIsPressed)
        {
            buttonIsPressed = false;
            // LockButtonIsPressed = !LockButtonIsPressed;
        }
    }


    public override void resetButton()
    {
        if (LockButtonIsPressed)
        {
            TweenableVariable.target = button.transform.parent.transform.InverseTransformPoint(middlePoint.position);
        }
        else
        {
            TweenableVariable.target = buttonOriginalLocalPosition;
        }

        checkButtonPressed(buttonOriginalLocalPosition.y);
    }

}
