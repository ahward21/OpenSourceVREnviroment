using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit;

public class LaserPointy_SCR : MonoBehaviour
{
    private bool pointerState = false;
    LineRenderer laserLine;
    float laserRange = 1000f;

    // Start is called before the first frame update
    void Start()
    {
        laserLine = GetComponent<LineRenderer>();
    }

    // Update is called once per frame
    void Update()
    {
        if (pointerState)
        {
            RaycastHit hit;
            laserLine.SetPosition(0, transform.position);
            //checks if the laser is turned on 
            if (pointerState)
            {
                //If the raycast hits an object, the laser should stop at the point of collision
                if (Physics.Raycast(transform.position, transform.up, out hit))
                {
                    if (hit.collider)
                    {
                        laserLine.SetPosition(1, hit.point);
                    }
                }
                //otherwise the laser will continue till it reaches a predetermined lenght (laserRange)
                else laserLine.SetPosition(1, (transform.up * laserRange));
            }
        }
        else
        {
            //deactivate
            laserLine.SetPosition(0, Vector3.zero);
            laserLine.SetPosition(1, Vector3.zero);
        }

    }

    public void CastLaser()
    {
        pointerState = !pointerState;
    }
}
