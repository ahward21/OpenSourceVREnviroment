using System;
using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit.AffordanceSystem.State;
using UnityEngine.XR.Interaction.Toolkit.Filtering;
using UnityEngine.XR.Interaction.Toolkit.Utilities.Tweenables.Primitives;
using UnityEngine.Events;

public class PokeButton_SCR : MonoBehaviour
{
    public GameObject button;
    public GameObject endPoint;

    [SerializeField]
    private float smoothingSpeed = 16f;

    [SerializeField]
    [Tooltip("The distance from the endpoint that the button detects a press")]
    public float pressThreshold = 0.0001f;


    [Header("Events")]
    [Space(10)]
    public UnityEvent onButtonPressed;

    public UnityEvent onButtonReleased;

    IPokeStateDataProvider m_PokeDataProvider;
    IMultiPokeStateDataProvider m_MultiPokeStateDataProvider;

    [HideInInspector]
    public readonly Vector3TweenableVariable TweenableVariable = new Vector3TweenableVariable();

    [HideInInspector]
    public Vector3 buttonOriginalLocalPosition;

    [HideInInspector]
    public bool buttonIsPressed = false;

    void Awake()
    {
        m_MultiPokeStateDataProvider = GetComponentInParent<IMultiPokeStateDataProvider>();
        if (m_MultiPokeStateDataProvider == null)
            m_PokeDataProvider = GetComponentInParent<IPokeStateDataProvider>();
    }


    // Start is called before the first frame update
    void Start()
    {
        if (button != null)
        {
            TweenableVariable.target = button.transform.localPosition;
            buttonOriginalLocalPosition = button.transform.localPosition;

            if (m_MultiPokeStateDataProvider != null)
                m_MultiPokeStateDataProvider.GetPokeStateDataForTarget(transform).Subscribe(OnPokeStateDataUpdated);
            else if (m_PokeDataProvider != null)
                m_PokeDataProvider.pokeStateData.SubscribeAndUpdate(OnPokeStateDataUpdated);
        }
    }

    void LateUpdate()
    {
        float tweenFactor = smoothingSpeed > 0 ? Time.deltaTime * smoothingSpeed : 1f;
        TweenableVariable.HandleTween(tweenFactor);
        if (button != null)
        {
            button.transform.localPosition = Vector3.Lerp(button.transform.localPosition, TweenableVariable.target, tweenFactor);
        }
    }

    public virtual void OnPokeStateDataUpdated(PokeStateData data)
    {
        var pokeTarget = data.target;
        var applyFollow = true
            ? pokeTarget != null && pokeTarget.IsChildOf(transform)
            : pokeTarget == transform;

        if (applyFollow)
        {
            // get the parent of the button
            var buttonsParent = button.transform.parent.transform;

            // get the poke interaction point
            var pokeInteractionPoint = data.pokeInteractionPoint;
            // get the closest point on the up axis of the button to the poke interaction point
            var closestPoint = buttonsParent.InverseTransformPoint(pokeInteractionPoint);

            // get the y position of the button in the parent's local space
            float endpointButtony = buttonsParent.InverseTransformPoint(endPoint.transform.position).y;

            // get the min and max y positions of the button in the parent's local space
            float min = Math.Min(endpointButtony, buttonOriginalLocalPosition.y);
            float max = Math.Max(endpointButtony, buttonOriginalLocalPosition.y);

            // clamp the y position of the closest point to the min and max y positions
            float clampedY = Mathf.Clamp(closestPoint.y, min, max);
            // set the new local position of the button
            newLocalPosition(new Vector3(button.transform.localPosition.x, clampedY, button.transform.localPosition.z));
            checkButtonPressed(clampedY);
        }
        else
        {
            resetButton();
        }

    }

    public virtual void newLocalPosition(Vector3 newLocalPosition)
    {
        TweenableVariable.target = newLocalPosition;
    }

    public virtual void checkButtonPressed(float clampedY)
    {
        // Get the y position of the endpoint in the button's local space
        float endpointButtony = button.transform.parent.transform.InverseTransformPoint(endPoint.transform.position).y;

        // Check if the button's position is within the threshold of the endpoint's position
        if (Mathf.Abs(clampedY - endpointButtony) <= pressThreshold && !buttonIsPressed)
        {
            // Log and invoke the button pressed event
            onButtonPressed.Invoke();

            //avoid consequent button press triggers
            buttonIsPressed = true;
            return;
        }
        else if (Mathf.Abs(clampedY - endpointButtony) > pressThreshold && buttonIsPressed)
        {
            buttonIsPressed = false;
            onButtonReleased.Invoke();
        }
    }


    public virtual void resetButton()
    {
        TweenableVariable.target = buttonOriginalLocalPosition;
        checkButtonPressed(buttonOriginalLocalPosition.y);
    }

}
