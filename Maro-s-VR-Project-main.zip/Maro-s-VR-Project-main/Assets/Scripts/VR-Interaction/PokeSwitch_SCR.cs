using System;
using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit.AffordanceSystem.State;
using UnityEngine.XR.Interaction.Toolkit.Filtering;
using UnityEngine.XR.Interaction.Toolkit.Utilities.Tweenables.Primitives;
using UnityEngine.Events;

public class PokeSwitch_SCR : MonoBehaviour
{
    public GameObject button;

    [SerializeField]
    private float smoothingSpeed = 16f;

    public Vector3 targetRotation;

    private Quaternion targetQuaternion;

    [HideInInspector]
    public Quaternion originalQuaternion;

    [HideInInspector]
    public readonly QuaternionTweenableVariable TweenableVariable = new QuaternionTweenableVariable();

    IPokeStateDataProvider m_PokeDataProvider;
    IMultiPokeStateDataProvider m_MultiPokeStateDataProvider;

    [Header("Events")]
    [Space(10)]
    public UnityEvent onButtonPressed;

    public UnityEvent onButtonReleased;

    // Start is called before the first frame update
    void Start()
    {
        if (button != null)
        {
            TweenableVariable.target = button.transform.rotation;
            originalQuaternion = button.transform.rotation;
            targetQuaternion = Quaternion.Euler(targetRotation);

            if (m_MultiPokeStateDataProvider != null)
                m_MultiPokeStateDataProvider.GetPokeStateDataForTarget(transform).Subscribe(OnPokeStateDataUpdated);
            else if (m_PokeDataProvider != null)
                m_PokeDataProvider.pokeStateData.SubscribeAndUpdate(OnPokeStateDataUpdated);
        }
    }

    void Awake()
    {
        m_MultiPokeStateDataProvider = GetComponentInParent<IMultiPokeStateDataProvider>();
        if (m_MultiPokeStateDataProvider == null)
            m_PokeDataProvider = GetComponentInParent<IPokeStateDataProvider>();
    }

    void LateUpdate()
    {
        float tweenFactor = smoothingSpeed > 0 ? Time.deltaTime * smoothingSpeed : 1f;
        TweenableVariable.HandleTween(tweenFactor);
        if (button != null)
        {
            button.transform.rotation = Quaternion.Lerp(button.transform.rotation, TweenableVariable.target, tweenFactor);
        }
    }


    void OnPokeStateDataUpdated(PokeStateData data)
    {
        var pokeTarget = data.target;
        var applyFollow = true
            ? pokeTarget != null && pokeTarget.IsChildOf(transform)
            : pokeTarget == transform;

        if (applyFollow)
        {

        }
    }

}
