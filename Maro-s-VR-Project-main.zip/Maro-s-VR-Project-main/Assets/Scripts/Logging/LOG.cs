﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using System;
using System.IO;
using System.Text;


public class LOG : Singleton<LOG>
{
    protected LOG() { } // singleton only - no constructor

    public bool isLogging { get; private set; } = true;
    public SessionData session;

    float updateFreq = 5F;

    List<LOG.Timeseries> postStack;
    string dataPath;

    public class SessionData
    {
        public string userId;
        public string userName;

        public override string ToString()
        {
            return UnityEngine.JsonUtility.ToJson(this, true);
        }
    }

    struct Timeseries
    {
        public string timestamp;
        public string logtype;
        public string logline;
    }

    static System.DateTime epochStart = new System.DateTime(1970, 1, 1, 0, 0, 0, System.DateTimeKind.Utc);


    public void Init()
    {
        if (!isLogging)
        {
            Debug.LogWarning("Logging Disabled! Not Initializing.");
            return;
        }

        postStack = new List<LOG.Timeseries>();
        dataPath = Path.Combine(
            Directory.GetParent(Application.dataPath).FullName,
            "LogData",
            session.userId.ToString()
            );
        EnsureFolderExists(dataPath);

        // Create Session File
        File.WriteAllText(Path.Combine(dataPath, "data.json"),session.ToString());

        InvokeRepeating("PostTimeseriesStack", 1F, updateFreq);
    }


    void PostTimeseriesStack()
    {
        if (postStack.Count <= 0)
        {
            Debug.Log("No updates to post");
            return;
        }

        AppendTimeseriesToTSV();
    }




    public void AddToTimeseries(string type, string content)
    {
        LOG.Timeseries ts = new()
        {
            timestamp = returnCurrentMilliEpoch(),
            logtype = type.Replace("\t", " "),
            logline = content.Replace("\t", " ")
        };

        postStack.Add(ts);
    }


    public void AppendTimeseriesToTSV()
    {
        // Define the file path within the Assets directory
        string filePath = Path.Combine(dataPath, "timeseries.tsv");

        // Check if the file already exists
        bool fileExists = File.Exists(filePath);

        // Use StringBuilder to prepare data to be written or appended
        StringBuilder tsvContent = new StringBuilder();

        // If the file does not exist, add a header row - based on
        if (!fileExists)
        {
            tsvContent.AppendLine("timestamp\tlogtype\tlogline");
        }

        foreach (var item in postStack)
        {
            tsvContent.AppendLine($"{item.timestamp}\t{item.logtype}\t{item.logline}");
        }

        File.AppendAllText(filePath, tsvContent.ToString());
        postStack.Clear();
    }


    static string returnCurrentMilliEpoch()
    {
        int cur_time = (int)(System.DateTime.UtcNow - epochStart).TotalSeconds;
        return cur_time.ToString() + "." + System.DateTime.UtcNow.Millisecond.ToString("000");
    }


    static void EnsureFolderExists(string folderPath)
    {
        // Check if the folder exists
        if (!Directory.Exists(folderPath))
        {
            // The folder does not exist, so create it
            Directory.CreateDirectory(folderPath);
            Debug.Log($"Folder created at: {folderPath}");
        }
    }

}
